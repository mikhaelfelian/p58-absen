<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'reference' => NULL,
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'reference' => NULL,
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'ifsnop/mysqldump-php' => array(
            'pretty_version' => 'v2.12',
            'version' => '2.12.0.0',
            'reference' => '2d3a43fc0c49f23bf7dee392b0dd1f8c799f89d3',
            'type' => 'library',
            'install_path' => __DIR__ . '/../ifsnop/mysqldump-php',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
