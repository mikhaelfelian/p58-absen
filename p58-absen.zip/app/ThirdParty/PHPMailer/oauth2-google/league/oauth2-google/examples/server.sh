#!/bin/bash

php -S localhost:8080
